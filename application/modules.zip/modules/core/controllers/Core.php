<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once ("secure_area.php");

class Core extends Secure_area {
	
	public function __construct()
	{
		parent::__construct();

	}

	public function index()
	{
		$this->data['page'] = 'dashboard';
		$this->data['no_students'] = $this->corem->get_no_usertype('student');
		$this->data['no_staffs'] = $this->corem->get_no_usertype('staff');
		$this->data['no_parents'] = $this->corem->get_no_usertype('parent');
		$this->data['no_subjects'] = $this->corem->get_no_subjects();

		$this->load->template('core/dashboard', $this->data);

	}
}
