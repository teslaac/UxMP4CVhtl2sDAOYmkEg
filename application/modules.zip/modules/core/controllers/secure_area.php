<?php
class Secure_area extends MX_Controller 
{
	var $module_id;
	public $userdata;
	
	/*
	Controllers that are considered secure extend Secure_area, optionally a $module_id can
	be set to also check if a user can access a particular module in the system.
	*/
	public $data = [];
	
	public function __construct($module_id=null)
	{
		parent::__construct();

		//$subdomain_arr = explode('.', $_SERVER['HTTP_HOST'], 2);
        //echo $subdomain_name = $subdomain_arr[0];
		
		//var_dump($this->session->userdata('user_id'));
		// user session data
		$data['userdata'] = $this->session->userdata;


		$this->module_id = $module_id;	
		$this->load->model('users/user_model');
		$this->load->model('core/School');
		$this->load->model('modules/Module');
		
		if(!$this->user_model->is_logged_in())
		{
			redirect(base_url().'login');
		}

		
		if(!$this->user_model->has_module_permission($this->module_id,$this->user_model->get_logged_in_user_info()->user_id))
		{
			//redirect('no_access/'.$this->module_id);
		}


		
		//load up global data
		$logged_in_user_info = $this->user_model->get_logged_in_user_info();
		$allowed_modules[] =$this->Module->get_allowed_modules($logged_in_user_info->user_id, 'user');
		$allowed_modules[] =$this->Module->get_allowed_modules($logged_in_user_info->user_type, 'group');
		//$allowed_modules[] = $this->Module->get_allowed_modules($logged_in_user_info->user_id, 'role');
		$data['allowed_modules'] = $allowed_modules;


  		//userdata
  		$this->userdata = $data['userdata'];

		//list all submenu from a module
		$allowed_modules_submenu = $data['allowed_modules_submenu']=$this->Module->get_allowed_modules_submenu($module_id, $this->userdata['user_id'], $this->userdata['user_type']);
 
// echo '<pre>';
// // print_r($allowed_modules_submenu); 
// //print_r($allowed_modules);exit();
// echo '</pre>';



		$data['user_info']=$logged_in_user_info;
		
		$schools_list=$this->School->get_all();
		$authenticated_schools = $this->user_model->get_authenticated_school_ids($logged_in_user_info->user_id);
		$schools = array();
		foreach($schools_list->result() as $row)
		{
			if(in_array($row->sch_id, $authenticated_schools))
			{
				$schools[$row->sch_id] = $row->sch_full_name;
			}
		}
		
		// $data['authenticated_schools'] = $schools;
		$this->load->vars($data);

	}
	
	function check_action_permission($action_id)
	{
		if (!$this->user_model->has_module_action_permission($this->module_id, $action_id, $this->user_model->get_logged_in_user_model_info()->person_id))
		{
			redirect('no_access/'.$this->module_id);
		}
	}	
 }	

?>