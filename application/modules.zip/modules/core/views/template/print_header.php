<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Acadah  | Smart School </title>
  <meta name="description" content="app, web app, responsive, responsive layout, admin, admin panel, admin dashboard, flat, flat ui, ui kit, AngularJS, ui route, charts, widgets, components" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/animate.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/font.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/app.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/print.css" type="text/css" />
</head>
<body>

    <!-- navbar -->
      <div class="page-container container" style="background-color:white; min-height:800px; padding: 20px; width:990px; ">
      
      <div class="col-xs-12">
        <div class="col-xs-2">
              <div class="logo">
                <img src="http://localhost/acadah_app/img/ccclear.png" alt="" width="115" height="115">
              </div>
        </div>

        <div class="col-xs-10" style="padding:10px 0 0 -30px">
              <div class="headings" >
                  <h3>TAI SOLARIN UNIVERSITY OF EDUCATION SECONDARY SCHOOL</h3>
                  <h4><span class="">CONSISTENCY AND TRUST IN GOD</span></h4>
                  <h4>P.M.B. 2118, Ijebu Ode, Ogun State, Nigeria</h4>
                  <h6>Email: <b>surevilleschools2006@gmail.com</b> Web: <b>surevilleschools.com</b> Phone: <b>07038917937</b></h6>
               </div>   
        </div> 
      </div>



