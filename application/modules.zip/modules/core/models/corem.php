<?php
/**
 * Created by PhpStorm.
 * User: SALAKO
 * Date: 10-Feb-16
 * Time: 2:41 PM
 */
Class Corem extends CI_Model{
    /**
     * Function Written By Tes Sal
     *  Basically the function will query the database and return the number of column in the database
     * It collects one parameter which is the type of usertype to count for whether student,parent or staff
     * @param $usertype
     * @return numeric
     */
    public function get_no_usertype($usertype){
        $sch_id = $_SESSION['sch_id'];
        $this->db->select("*");
        $this->db->from('acadah_users');
        $this->db->where('sch_id',$sch_id);
        $this->db->where('user_type',$usertype);
        $query = $this->db->get();
        return $query->num_rows();
    }

    /**
     * Function Written By Tes Sal
     * The Function has no pparameters and basically just return the number of courses available to that particular school using session_sch_id
     * @return numeric
     */
    public function get_no_subjects($count = TRUE){
        $sch_id = $_SESSION['sch_id'];
        $join = array("acadah_app_subject", "acadah_app_subject.subject_id=acadah_school_subject.subject_id");

        $this->db->select("*");
        $this->db->from('acadah_school_subject');
        $this->db->join($join[0], $join[1]);
        $this->db->where('sch_id',$sch_id);
        $query = $this->db->get();
        if($count === TRUE) {
            return $query->num_rows();
        }else{
            return $query->result_array();
        }
    }

    public function get_no_class($count = TRUE){
        $sch_id = $_SESSION['sch_id'];
        $this->db->select("*");
        $this->db->from('acadah_class_details');
        $this->db->where('sch_id',$sch_id);
        $query = $this->db->get();
        if($count === TRUE) {
            return $query->num_rows();
        }else{
            return $query->result_array();
        }
    }
    /**
     * Function Written By Tes Sal
     * This function gets the number of male/female in the database, It collects two parameters
     * The first one is the gender you wanna count for whether male/female
     * The second is the usertype whether for staff/student/parent
     * @param $gender
     * @param $usertype
     * @return numeric
     */
    public function get_no_gender($gender,$usertype){
        $sch_id = $_SESSION['sch_id'];
        $this->db->select("*");
        $this->db->from('acadah_users');
        $this->db->where('sch_id',$sch_id);
        $this->db->where('user_type',$usertype);
        $this->db->where('gender',$gender);
        $query = $this->db->get();
        return $query->num_rows();
    }

    /**
     * Function Written By Tes Sal
     * @param $search
     * Search is the item you wanna search for in the where query e.g. where $search = $search_key
     * @param $search_key
     * This is the value you are passing to the where query i.e. where $search = $search_key
     * @param $table
     * Table is the table you are joining on
     * @param $foreign_key
     * Foreign Key is the foreign key in that table
     * @param $where_table
     * Where_table is the table you are searching Select * from $where_table
     * @param $on
     * on is what would be used in the join query e.g.
     * SELECT * FROM $where_table JOIN $table ON $table.$foreign_key=$where_table.$on where $search = $search_key
     * @param bool $loop
     * Whether to return the last row or all rows, default is all rows
     * @param $more
     *
     * @return mixed
     */

    public function get_any($search,$search_key,$table,$foreign_key,$where_table,$on,$loop = TRUE){
        $sch_id = $_SESSION['sch_id'];
        if(empty($search)){
            $where = array("$where_table.sch_id"=>$sch_id);
        }else{
            $where = array("$where_table.sch_id"=>$sch_id,"$search"=>"$search_key");
        }
        if(!empty($table)){
            $join = array("$table", "$table.$foreign_key=$where_table.$on");
            $query = $this->db->join($join[0], $join[1])->get_where($where_table, $where);
        }else{
            $query = $this->db->get_where($where_table, $where);
        }

        if($loop === TRUE){
            return $query->result_array();
        }else {
            return $query->row_array();
        }
    }

    public function add_subject($sdata,$type){
        if($type == 'student'){
            $table = 'acadah_student_subjects';
        }elseif($type == 'staff'){
            $table = 'acadah_staff_subjects';
        }
        $query = $this->db->insert($table,$sdata);
        if(!$query){
            return FALSE;
        }else{
            return TRUE;
        }
    }

    public function get_session($count = TRUE){
        $sch_id = $_SESSION['sch_id'];
        $join = array("acadah_app_session", "acadah_school_session.session_id=acadah_app_session.session_id");

        $this->db->select("*");
        $this->db->from('acadah_school_session');
        $this->db->join($join[0], $join[1]);
        $this->db->where('sch_id',$sch_id);
        $query = $this->db->get();
        if($count === TRUE) {
            return $query->num_rows();
        }else{
            return $query->result_array();
        }
    }

    public function term_session(){
        $sch_id = $_SESSION['sch_id'];
        $where = array('acadah_term_session.sch_id'=>$sch_id,'acadah_school_session.sch_id'=>$sch_id,'acadah_school_term.sch_id'=>$sch_id);
        $join = array("acadah_school_session", "acadah_term_session.session_id=acadah_school_session.session_id");
        $join1 = array("acadah_app_session", "acadah_app_session.session_id=acadah_term_session.session_id");
        $join2 = array("acadah_school_term", "acadah_school_term.term_id=acadah_term_session.term_id");
        $this->db->select("*");
        $this->db->from('acadah_term_session');
        $this->db->join($join[0], $join[1]);
        $this->db->join($join1[0], $join1[1]);
        $this->db->join($join2[0], $join2[1]);
        $this->db->where($where);
        $query = $this->db->get();
            return $query->result_array();

    }

//awonugaso
public function active_term_session($field = '', $sch_id){
        
        $this->db->from('acadah_app_term_session sts');
        $this->db->join("acadah_school_term_session ats", "ats.ts_id = sts.ts_id and ats.sch_id ='$sch_id' and ts_active = 1");
        $this->db->join("acadah_school_session sses", "sts.session_id=sses.session_id and sses.sch_id ='$sch_id'");
        $this->db->join("acadah_school_term sterm", "sts.term_id=sterm.term_id and sterm.sch_id ='$sch_id'");
        $query = $this->db->get();
        //die ($this->db->last_query());

        if( $field === ''){ //then all fields are needed
            return $query->result_array()[0];
        }else{ //send only the requested field
            return $query->result_array()[0]['ts_id'];
        }
    }

    public function get_app_any($count = FALSE,$table){
        $this->db->select("*");
        $this->db->from("acadah_app_".$table);
        $query = $this->db->get();
        if($count === TRUE) {
            return $query->num_rows();
        }else{
            return $query->result_array();
        }
    }



    public function subjects_details($id,$count = FALSE, $type){
        $sch_id = $_SESSION['sch_id'];
        if($type == 'student'){
            $table = 'acadah_student_subjects';
            $user_id = 'student_id';
        }elseif($type == 'staff'){
            $table = 'acadah_staff_subjects';
            $user_id = 'staff_id';
            $join1 = array("acadah_class_details", "acadah_class_details.class_details_id=$table.class_details_id");
        }
        $join = array("acadah_app_subject", "acadah_app_subject.subject_id=$table.subject_id");
        $join2 = array("acadah_app_session", "acadah_app_session.session_id=$table.session_id");
        $where = array("$table.sch_id"=>$sch_id,$user_id=>$id);

        $this->db->select("*");
        $this->db->from($table);
        $this->db->join($join[0], $join[1]);
        if($type== 'staff') {
            $this->db->join($join1[0], $join1[1]);
        }
        $this->db->join($join2[0], $join2[1]);
        $this->db->where($where);
        $query = $this->db->get();
        if($count === TRUE) {
            return $query->num_rows();
        }else{
            return $query->result_array();
        }
    }

    public function get_states(){
        $this->db->select("*");
        $this->db->from('acadah_app_states');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function get_sport_house(){
        $sch_id = $_SESSION['sch_id'];
        $this->db->select("*");
        $this->db->from('acadah_sport_house');
        $this->db->where('sch_id',$sch_id);
        $query = $this->db->get();
        return $query->result_array();
    }


    /**
     * Generate a License Key.
     * Optional Suffix can be an integer or valid IPv4, either of which is converted to Base36 equivalent
     * If Suffix is neither Numeric or IPv4, the string itself is appended
     *
     * @param   string  $suffix Append this to generated Key.
     * @return  string
     */
    function generate_license($suffix = null) {
        // Default tokens contain no "ambiguous" characters: 1,i,0,o
        if(isset($suffix)){
            // Fewer segments if appending suffix
            $num_segments = 3;
            $segment_chars = 6;
        }else{
            $num_segments = 4;
            $segment_chars = 5;
        }
        $tokens = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $license_string = '';
        // Build Default License String
        for ($i = 0; $i < $num_segments; $i++) {
            $segment = '';
            for ($j = 0; $j < $segment_chars; $j++) {
                $segment .= $tokens[rand(0, strlen($tokens)-1)];
            }
            $license_string .= $segment;
            if ($i < ($num_segments - 1)) {
                $license_string .= '-';
            }
        }
        // If provided, convert Suffix
        if(isset($suffix)){
            if(is_numeric($suffix)) {   // Userid provided
                $license_string .= '-'.strtoupper(base_convert($suffix,10,36));
            }else{
                $long = sprintf("%u\n", ip2long($suffix),true);
                if($suffix === long2ip($long) ) {
                    $license_string .= '-'.strtoupper(base_convert($long,10,36));
                }else{
                    $license_string .= '-'.strtoupper(str_ireplace(' ','-',$suffix));
                }
            }
        }
        return $license_string;
    }

    public function save_school($udata,$odata,$edit = FALSE){
        if($edit === FALSE){
            $this->db->insert('acadah_school',$odata);
            $sch_id = $this->db->insert_id();
            $activation_code = $this->generate_license($sch_id);
            $this->db->update('acadah_school',array('activation_code'=>md5($activation_code)),array('id'=>$sch_id));
            $query = $this->db->insert('acadah_users',$udata);
            if($query) {
                $usercode = $odata['sch_id'] . "-" . $this->db->insert_id();
                $this->db->set('user_id', $usercode);
                $this->db->where('id', $this->db->insert_id());
                $usercode_update = $this->db->update('acadah_users');
                $subject = "$odata[sch_full_name] Registration Successful and Activation Code<br/>";
                $message = "Your registration on Acadah was successful and below are the details you need to login and activate your school<br/>";
                $message .= "Login URL: base_url()<br/>";
                $message .= "Email: $udata[email]<br/>";
                $message .= "Password: Your Password<br/>";
                $message .= "Activation Code: $activation_code";
                $to = $udata['email'];
                //  $this->send_emails($to,$subject,$message);
                $this->session->set_flashdata('activation_code', $activation_code);
                $this->session->set_flashdata('email', $to);
            }
        }else{

            $query = $this->db->update('acadah_school',$odata,array('sch_id'=>$_SESSION['sch_id']));
            if($query){
                $this->db->update('acadah_users',$udata,array('sch_id'=>$_SESSION['sch_id'],'user_type'=>'superadmin'));
            }
        }

        if($query){
            return TRUE;
        }else{
            return FALSE;
        }
    }

    public function send_emails($to,$subject,$message){
        $config['mailtype'] = 'html';
        $this->email->initialize($config);
        $this->email->from('support@acadah.com', 'Acadah Inc');
        $this->email->to($to);
//        $this->email->cc('another@another-example.com');
//        $this->email->bcc('them@their-example.com');

        $this->email->subject($subject);
        $this->email->message($message);

        return $this->email->send();
    }

    public function get_school_details($sch_id = FALSE){
        if($sch_id === FALSE) {
            $sch_id = $_SESSION['sch_id'];
        }
        $join = array("acadah_users", "acadah_users.sch_id=acadah_school.sch_id");
        $where = array("acadah_school.sch_id"=>$sch_id,"acadah_users.user_type"=>"superadmin");
        $this->db->select("*");
        $this->db->from('acadah_school');
        $this->db->join($join[0], $join[1]);
        $this->db->where($where);
        $query = $this->db->get();
//        print_r($query->row_array());die();
        return $query->row_array();
    }

    public function classd_details(){
        $sch_id = $_SESSION['sch_id'];
        $join = array("acadah_class_desc", "acadah_class_details.class_desc_id=acadah_class_desc.class_desc_id");
        $join1 = array("acadah_app_level", "acadah_class_details.class_level=acadah_app_level.level_id");
        $where = array("acadah_class_details.sch_id"=>$sch_id,"acadah_class_desc.sch_id"=>$sch_id);
        $this->db->select("*");
        $this->db->from('acadah_class_details');
        $this->db->join($join[0], $join[1]);
        $this->db->join($join1[0], $join1[1]);
        $this->db->where($where);
        $query = $this->db->get();
//        print_r($query->row_array());die();
        return $query->result_array();
    }

    public function subject_details(){
        $sch_id = $_SESSION['sch_id'];
        $join = array("acadah_app_subject_dept", "acadah_app_subject_dept.dept_id=acadah_school_subject.department_id");
        $join1 = array("acadah_school_div", "acadah_school_div.school_div_id=acadah_school_subject.school_div_id");
        $join2 = array("acadah_app_subject", "acadah_app_subject.subject_id=acadah_school_subject.subject_id");
        $where = array("acadah_school_subject.sch_id"=>$sch_id,"acadah_school_div.sch_id"=>$sch_id);
        $this->db->select("*");
        $this->db->from('acadah_school_subject');
        $this->db->join($join[0], $join[1]);
        $this->db->join($join1[0], $join1[1]);
        $this->db->join($join2[0], $join2[1]);
        $this->db->where($where);
        $query = $this->db->get();
//        print_r($query->row_array());die();
        return $query->result_array();
    }

    public function sd_details(){
        $sch_id = $_SESSION['sch_id'];
        $join = array("acadah_app_subject_dept", "acadah_app_subject_dept.dept_id=acadah_subject_dept.dept_id");
        //$join1 = array("acadah_app_level", "acadah_class_details.class_level=acadah_app_level.level_id");
        $where = array("acadah_subject_dept.sch_id"=>$sch_id);
        $this->db->select("*");
        $this->db->from('acadah_subject_dept');
        $this->db->join($join[0], $join[1]);
       // $this->db->join($join1[0], $join1[1]);
        $this->db->where($where);
        $query = $this->db->get();
//        print_r($query->row_array());die();
        return $query->result_array();
    }

    public function save_setup($table,$data,$edit = FALSE){
    if($edit === FALSE){
        $query = $this->db->insert($table,$data);
    }else{
        if($table == 'acadah_school_session'){
        $query = $this->db->update($table,$data,array('sch_id'=>$_SESSION['sch_id'],'session_id'=>$edit));}
        else{
            $query = $this->db->update($table,$data,array('sch_id'=>$_SESSION['sch_id'],'session_id'=>$edit));
        }
    }
        if($query){
            return TRUE;
        }else{
            return FALSE;
        }
    }

    public function validate_license($license){
        $sch_id = $_SESSION['sch_id'];
        $this->db->select("*");
        $this->db->from('acadah_school');
        $this->db->where('activation_code',$license);
        $this->db->where('sch_id',$sch_id);
        $query = $this->db->get();
        $count = $query->num_rows();
        if($count == 1){
            $this->db->update('acadah_school',array('activated_status'=>'1'),array('sch_id'=>$sch_id));
        }
        return $query->num_rows();
    }
}