			<section>
				<div class="col-sm-12 text-center">
					<h4>PAYMENT RECORDS FOR GTBANK ACCOUNT</h4><br>
				</div>
				<div class="col-sm-12">
					<h4>FROM <span class="text-info">03, FEBRUARY, 2016 </span>TO <span class="text-info">04, FEBRUARY, 2016</span></h4>
				</div>
				<br/><br/><br/><br/><br/>
				<div class="col-sm-12">
					<table class="table table-hover">
					<thead>
						<tr style="background:#D9EDF7">
							<th>No</th>
							<th>Date</th>
							<th>Voucher No</th>
							<th>Name</th>
							<th>Payment Details</th>
							<th>Inflow</th>
							<th>Outflow</th>
							<th>balance</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td></td>
							<td>12345</td>
							<td>Adugbe Toluwani</td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td colspan="5" class="text-right">Total :</td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
					</tbody>
				</div>
			</section>
		</div>
		
	</body>
</html>