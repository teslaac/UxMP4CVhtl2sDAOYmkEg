			<section>
				<div class="col-sm-12 text-center">
					<h4>STUDENT PAYMENT SUMMARY (ALL RECORDS)</h4><br>
				</div>
				<div class="col-sm-12">
				<table class="table table-hover">
					<tbody>
						<tr>
							<td>Session:  2014/2015</td>
							<td>term:  1st Term</td>
						</tr>
					</tbody>
				</table>
				</div>
				<div class="col-sm-12">
					<table class="table table-hover">
					<thead>
						<tr style="background:#D9EDF7">
							<th>No</th>
							<th>Name</th>
							<th>Class</th>
							<th>Main Bill</th>
							<th>Outstanding</th>
							<th>Extra Bill</th>
							<th>Total Amount</th>
							<th>Total Paid</th>
							<th>Total Debt</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
						<tr>
							<td>1</td>
							<td>ABANG GLORY</td>
							<td>PLAYGROUP</td>
							<td>₦160,750</td>
							<td>₦0 </td>
							<td>₦110,000</td>
							<td>₦ 270,750</td>
							<td>₦215,050</td>
							<td>₦35,700</td>
							<td>700</td>
						</tr>
					</tbody>
				</table>
				</div>
			</section>
		</div>
		
	</body>
</html>