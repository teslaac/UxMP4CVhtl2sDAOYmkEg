
<div class="col-xs-4 col-xs-offset-4 text-info"> <h3> APPLICATION FORM </h3></div>

        <!-- Page content -->
        <div class="page-content">
			<div class="widget">
                
                    <div class="panel-body">						

						<div class="col-xs-9">
								<div class="widget">
									<div class="panel panel-default">
										<div class="panel-heading"><h6 class="panel-title"> APPLICATION DETAILS </h6></div>
										<div class="table-responsive">
											<table class="table table-striped bold">
												<tbody>
													<tr>
														<td width="25%">Form Number:</td>
														<td>DP-FT2</td>
													</tr>
													<tr>
														<td>Class Applied:</td>
														<td> JSS 1</td>
													</tr>

													<tr>
														<td>Day/Boarding:</td>
														<td> Boarding </td>
													</tr>

													<tr>
														<td>Application Date:</td>
														<td> 22/12/2012</td>
													</tr>										
	
												</tbody>
											</table>
										</div>
									</div>
								</div>					
							</div>
							
							<div class="col-xs-3">                 
								<div class="widget ">
  									<div class="thumbnail text-center">
  										<div class="" style="padding: 30px; ">
  										<i class="fa fa-user" style=" font-size: 105px; "></i>
  										</div>
  									</div>
								</div>								
							</div>

							<div class="col-xs-12">
								<div class="widget">
									<div class="panel panel-default">
										<div class="panel-heading"><h6 class="panel-title"> PERSONAL DATA </h6></div>
										<div class="panel-body">
										<div class="col-xs-6">												
											<div class="panel panel-default">
												<div class="table-responsive">
													<table class="table  table-striped  bold">
														<tbody>
																<tr>
																	<td width="130px">Surname:</td>
																	<td> ADEDOYIN</td>
																</tr>
																<tr>
																	<td width="">First Name:</td>
																	<td>ENIOLA</td>
																</tr>
																<tr>
																	<td width="">Middle Name:</td>
																	<td> EMMANUEL </td>
																</tr>
																<tr>
																	<td>Phone Number :</td>
																	<td>08180330299</td> 
																</tr>
																<tr>
																	<td>Date Of Birth :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>State of Origin :</td>
																	<td>Other</td> 
																</tr>
																<tr>
																	<td>LGA of Origin  :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>Nationality :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>Gender :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>E-Mail Address :</td>
																	<td>hennysam2008@yahoo.com</td> 
																</tr>										
																<tr>
																	<td>Hometown :</td>
																	<td></td> 
																</tr>
																
															</tbody>
														</table>
													</div>
												</div>
											</div>
											
											<div class="col-xs-6">
												<div class="panel panel-default">														
													<div class="table-responsive">
														<table class="table table-striped bold">
															<tbody>
																
																<tr>
																	<td>Religion :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>Residential Address :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>Residential State :</td>
																	<td></td> 
																</tr>
																<tr>
																	<td>Residential Country :</td>
																	<td></td> 
																</tr>
																
															</tbody>
														</table>
													</div>
												</div>

												<div class="panel panel-default">
													<div class="panel-heading"><h6 class="panel-title">MEDICAL INFO</h6></div>
													<div class="table-responsive">
														<table class="table bold">
															<tbody> 

																<tr>
																	<td>Height:</td>
																	<td> </td>
																</tr>
																<tr>
																	<td>Weight: </td>
																	<td></td> 
																</tr>								
																<tr>
																	<td>Disablity: </td>
																	<td></td>
																</tr>								
																<tr>
																	<td>Genotype:</td>
																	<td></td> 
																</tr>													
																<tr>
																	<td>Bloodgroup: </td>
																	<td></td> 
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
											
										<div class="clearfix"></div>
									</div>
								</div>					
							</div>
					 </div>                     
    			
            </div>            
       </div>
    </div>