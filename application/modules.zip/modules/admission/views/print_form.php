<?php 

include 'inc_profile.php';

?>