<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<?php
	if($student_details['sch_id'] !== $_SESSION['sch_id']){
		redirect("students");
	}elseif($_SESSION['user_type'] !== 'admin' and $_SESSION['user_id'] !== $student_details['user_id']){
		redirect("students");
	}


?>
<script>
	$(document).ready( function () {
		$('#list').DataTable();
	} );


</script>
    <!-- content -->
    <div class="app-content">
      <div ui-butterbar></div>
      <a href class="off-screen-toggle hide" data-toggle="class:off-screen" data-target=".app-aside" ></a>
      <div class="app-content-body fade-in-up">
        <!-- COPY the content from "tpl/" -->
		<div class="bg-light lter b-b wrapper-md">

		  <span class="pull-right" >
		  	<button class="btn btn-default btn-addon  "><i class="icon-user-female"></i></i>PARENT INFO</button>
		  </span>

		  <h1 class="m-n font-thin h3">Edit Student</h1>

		</div>
		<div class="wrapper-md">

		<div class="col-md-12">

			<?php
			if(!empty($_SESSION['failed'])){?>
				<div class="alert alert-danger fade in widget-inner">
					<button type="button" class="close" data-dismiss="alert">x</button>
					<?php echo $_SESSION['failed']; ?>
				</div>
			<?php }elseif(!empty($_SESSION['success'])){?>
				<div class="alert alert-success fade in widget-inner">
					<button type="button" class="close" data-dismiss="alert">x</button>
					<?php echo $_SESSION['success'];?>
				</div>
			<?php }else{ ?>
			<div class="alert alert-info fade in widget-inner">
                <button type="button" class="close" data-dismiss="alert">x</button>
              Please Enter correct Information      
            </div>
			<?php } ?>
        </div>
			<form class="bs-example form-horizontal ng-pristine ng-valid" method="POST" action="<?php echo base_url(); ?>students/add_student/edit/<?php echo $student_details['user_id']; ?>">
				<div class="col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading ">PERSONAL DETAILS</div>
						<div class="panel-body">

							<div class="form-group">
								<?php echo form_error('sname'); ?>
								<label class="col-sm-4 control-label">Surname: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('sname',$student_details['lname']); ?>" name="sname" id="surname"  required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('fname'); ?>
								<label class="col-sm-4 control-label">First Name: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('fname',$student_details['fname']); ?>" name="fname" id="firstName"  required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('mname'); ?>
								<label class="col-sm-4 control-label">Other Name: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('mname',$student_details['mname']); ?>" name="mname" id="otherName"  required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('phone'); ?>
								<label class="col-sm-4 control-label">Phone Number: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('phone',$student_details['phone']); ?>" name="phone" id="phoneNumber" required="" type="number">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('email'); ?>
								<label class="col-sm-4 control-label">Email Address: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('email',$student_details['email']); ?>" name="email" id="emailAddress"  required="" type="email">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('gender'); ?>
								<label class="col-sm-4 control-label">Gender: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('gender',$student_details['gender']); ?>" name="gender"  required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('address'); ?>
								<label class="col-sm-4 control-label">Home Address: </label>
								<div class="col-sm-8">
									<input placeholder="Home Address" class="form-control" value="<?php echo set_value('address',$student_details['address']); ?>" name="address" required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('religion'); ?>
								<label class="col-sm-4 control-label">Religion: </label>
								<div class="col-sm-8">
									<select class="form-control" name="religion" id="religion" required="">
										<option <?php echo set_select('religion','Islam'); ?> value="Islam">Islam</option>
										<option <?php echo set_select('religion','',TRUE); ?> value="">---Select Religion---</option>
										<option <?php echo set_select('religion','Christianity'); ?> value="Christianity">Christianity</option>
										<option <?php echo set_select('religion','Traditional'); ?> value="Traditional">Traditional</option>
									</select>
								</div>
							</div>


							<div class="form-group">
								<?php echo form_error('dob'); ?>
								<label class="col-sm-4 control-label">D.O.B (DD/MM/YYYY): </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('dob',$student_details['dob']); ?>" name="dob" id="dob" required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('nationality'); ?>
								<label class="col-sm-4 control-label">Nationality: </label>
								<div class="col-sm-8">
									<input class="form-control" name="nationality" value="<?php echo set_value('nationality',$student_details['nationality']); ?>" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('state'); ?>
								<label class="col-sm-4 control-label">State:</label>
								<div class="col-sm-8">
									<select class="form-control state" name="state" required="">
										<!-- 								<option <?php echo set_select('state','Ogun'); ?> value="Ogun">Ogun</option> -->
										<option <?php echo set_select('state','',TRUE); ?> value=" ">Select</option>
										<option <?php echo set_select('state','Abia'); ?> value="Abia">Abia States</option>
										<option <?php echo set_select('state','Adamawa'); ?> value="Adamawa">Adamawa States</option>
										<option <?php echo set_select('state','Akwa Ibom'); ?> value="Akwa Ibom">Akwa Ibom States</option>
										<option <?php echo set_select('state','Anambra'); ?> value="Anambra">Anambra States</option>
										<option <?php echo set_select('state','Bauchi'); ?> value="Bauchi">Bauchi States</option>
										<option <?php echo set_select('state','Bayelsa'); ?> value="Bayelsa">Bayelsa States</option>
										<option <?php echo set_select('state','Benue'); ?> value="Benue">Benue States</option>
										<option <?php echo set_select('state','Borno'); ?> value="Borno">Borno States</option>
										<option <?php echo set_select('state','Cross River'); ?> value="Cross River">Cross River States</option>
										<option <?php echo set_select('state','Delta'); ?> value="Delta">Delta States</option>
										<option <?php echo set_select('state','Ebonyi'); ?> value="Ebonyi">Ebonyi States</option>
										<option <?php echo set_select('state','Edo'); ?> value="Edo">Edo States</option>
										<option <?php echo set_select('state','Ekiti'); ?> value="Ekiti">Ekiti States</option>
										<option <?php echo set_select('state','Enugu'); ?> value="Enugu">Enugu States</option>
										<option <?php echo set_select('state','FCT-Abuja'); ?> value="FCT-Abuja">FCT-Abuja</option>
										<option <?php echo set_select('state','Gombe'); ?> value="Gombe">Gombe States</option>
										<option <?php echo set_select('state','Imo'); ?> value="Imo">Imo States</option>
										<option <?php echo set_select('state','Jigawa'); ?> value="Jigawa">Jigawa States</option>
										<option <?php echo set_select('state','Kaduna'); ?> value="Kaduna">Kaduna States</option>
										<option <?php echo set_select('state','Kano'); ?> value="Kano">Kano States</option>
										<option <?php echo set_select('state','Katsina'); ?> value="Katsina">Katsina States</option>
										<option <?php echo set_select('state','Kebbi'); ?> value="Kebbi">Kebbi States</option>
										<option <?php echo set_select('state','Kogi'); ?> value="Kogi">Kogi States</option>
										<option <?php echo set_select('state','Kwara'); ?> value="Kwara">Kwara States</option>
										<option <?php echo set_select('state','Lagos'); ?> value="Lagos">Lagos States</option>
										<option <?php echo set_select('state','Nasarawa'); ?> value="Nasarawa">Nasarawa States</option>
										<option <?php echo set_select('state','Niger'); ?> value="Niger">Niger States</option>
										<option <?php echo set_select('state','Ogun'); ?> value="Ogun">Ogun States</option>
										<option <?php echo set_select('state','Ondo'); ?> value="Ondo">Ondo States</option>
										<option <?php echo set_select('state','Osun'); ?> value="Osun">Osun States</option>
										<option <?php echo set_select('state','Oyo'); ?> value="Oyo">Oyo States</option>
										<option <?php echo set_select('state','Plateau'); ?> value="Plateau">Plateau States</option>
										<option <?php echo set_select('state','Rivers'); ?> value="Rivers">Rivers States</option>
										<option <?php echo set_select('state','Sokoto'); ?> value="Sokoto">Sokoto States</option>
										<option <?php echo set_select('state','Taraba'); ?> value="Taraba">Taraba States</option>
										<option <?php echo set_select('state','Yobe'); ?> value="Yobe">Yobe States</option>
										<option <?php echo set_select('state','Zamfara'); ?> value="Zamfara">Zamfara States</option>
										<option <?php echo set_select('state','Non-Nigerian'); ?> value="Non-Nigerian">Non-Nigerian</option>
									</select>
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('lg'); ?>
								<label class="col-sm-4 control-label">Local Government Area:</label>
								<div class="col-sm-8">
									<select id="response" class="form-control lga" name="lg" required="">
										<option <?php echo set_select('lg','Ogun Waterside'); ?>  value="Ogun Waterside">Ogun Waterside</option>
										<option <?php echo set_select('lg','',TRUE); ?>  value="">Select</option>
									</select>
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('hometown'); ?>
								<label class="col-sm-4 control-label">Hometown: </label>
								<div class="col-sm-8">
									<input class="form-control" name="hometown" value="<?php echo set_value('hometown',$student_details['hometown']); ?>" type="text">
								</div>
							</div>


						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading ">ADMISSION INFO</div>
						<div class="panel-body">
							<!--  <form class="bs-example form-horizontal ng-pristine ng-valid">		 -->
							<div class="form-group">
								<?php echo form_error('admission_no'); ?>
								<label class="col-sm-4 control-label">Admission No: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('admission_no',$student_details['admission_no']); ?>" name="admission_no"   required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('admission_class'); ?>
								<label class="col-sm-4 control-label">Class: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('admission_class',$student_details['admission_class']); ?>" name="admission_class" id="class"  required="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('admission_date'); ?>
								<label class="col-sm-4 control-label">Admission Date: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('admission_date',$student_details['admission_date']); ?>" name="admission_date"  required="">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('sport_house'); ?>
								<label class="col-sm-4 control-label">Sport House: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('sport_house',$student_details['sport_house']); ?>" name="sport_house" id="" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('hostel_status'); ?>
								<label class="col-sm-4 control-label">Day/Boarding:: </label>
								<div class="col-sm-8">
									<input class="form-control" name="hostel_status" value="<?php echo set_value('hostel_status',$student_details['hostel_status']); ?>" type="text">
								</div>
							</div>


						</div>
					</div>
				</div>

				<div class="col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading ">MEDICAL INFO</div>
						<div class="panel-body">
							<!-- <form class="bs-example form-horizontal ng-pristine ng-valid"> -->
							<div class="form-group">
								<?php echo form_error('height'); ?>
								<label class="col-sm-4 control-label">Height: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('height',$student_details['height']); ?>" name="height">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('weight'); ?>
								<label class="col-sm-4 control-label">Weight: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('weight',$student_details['weight']); ?>" name="weight" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('disability'); ?>
								<label class="col-sm-4 control-label">Disablity: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('disability',$student_details['disability']); ?>" name="disability" type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('genotype'); ?>
								<label class="col-sm-4 control-label">Genotype: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('genotype',$student_details['genotype']); ?>" name="genotype"  type="text">
								</div>
							</div>

							<div class="form-group">
								<?php echo form_error('bloodgroup'); ?>
								<label class="col-sm-4 control-label">Bloodgroup: </label>
								<div class="col-sm-8">
									<input class="form-control" value="<?php echo set_value('bloodgroup',$student_details['bloodgroup']); ?>" name="bloodgroup" type="text">
								</div>
							</div>



						</div>
					</div>
				</div>

		<div class="col-md-12">
	    	<div class="panel panel-default">
	    		<div class="panel-body">
	    		<div class="form-actions text-right">
	    			<button class="btn btn-info btn-addon"><i class="fa fa-save"></i>Save</button>
	            </div>
	            </div>
	        </div>
        </div>

	    	<div class="clearfix"></div>
				<div class="wrapper-md">
					<div class="row m-b doc-buttons">
	                  <div class="col-sm-8">
	                  <a class="btn btn-primary" data-toggle="modal" href='#parent-modal'>Add Parent</a>
	                  </div>
<!--	                  <div class="col-sm-4">-->
<!--	                    <div class="input-group">-->
<!--	                      <input class="form-control" placeholder="Search" type="text">-->
<!--	                      <span class="input-group-btn">-->
<!--	                        <button class="btn btn-info" type="button">Go!</button>-->
<!--	                      </span>-->
<!--	                    </div>-->
<!--	                  </div>-->
	                </div>
					<section class="panel panel-default">
		                <header class="panel-heading">
		                  Parents Information Table
		                </header>
		                <div class="table-responsive">
		                  <table id="list" class="table table-striped table-hover b-t b-light">
		                    <thead>
		                      <tr>
		                      <th></th>
		                        <th class="th-sortable" data-toggle="class">No.</th>
		                        <th>Parent ID</th>
		                        <th>Title</th>
		                        <th>Full Name</th>
		                        <th>Initial</th>
		                        <th>Phone</th>
		                        <th>Email</th>
		                        <th colspan="3">Action</th>
		                      </tr>
		                    </thead>
		                    <tbody>
							<?php
							foreach($parents_details as $parent_detail) {
								if(empty($i)){
									$i = 1;
								}
								?>
								<tr>
									<td><input name="post[]" value="2" type="checkbox"></td>
									<td><?php echo $i; ?></td>
									<td><?php echo $parent_detail['user_id']; ?></td>
									<th><?php echo $parent_detail['title']; ?></th>
									<td><?php echo $parent_detail['lname']." ".$parent_detail['fname']." ".$parent_detail['mname']; ?></td>
									<td><?php echo $parent_detail['initial']; ?></td>
									<td><?php echo $parent_detail['phone']; ?></td>
									<td><?php echo $parent_detail['email']; ?></td>
									<td><a href="#" class="btn btn-xs btn-primary"><i class="fa fa-pencil"></i> Edit</a>
									</td>
									<td><a href="" class="btn btn-xs btn-danger"><i class="fa fa-times"></i> Disable</a>
									</td>
									<td><a href="#" class="btn btn-xs btn-info"><i class="fa fa-print"></i> Profile</a>
									</td>
								</tr>
								<?php
								$i++;
							}
							?>
		                    </tbody>
		                  </table>
		                </div>
		                <footer class="panel-footer">
		                  <div class="row">
		                    <div class="col-sm-4 hidden-xs">
		                      <select class="input-sm form-control input-s-sm inline v-middle">
		                        <option value="0">Bulk action</option>
		                        <option value="1">Delete selected</option>
		                        <option value="2">Bulk edit</option>
		                        <option value="3">Export</option>
		                      </select>
		                      <button class="btn btn-sm btn-default">Apply</button>
		                    </div>
		                  </div>
		                </footer>
		              </section>
		</div>

	    
		<div class="clearfix"></div>
</form>
    </div>
    <!-- /content -->
<div class="modal fade" id="parent-modal">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title"><i class="fa fa-plus"></i>ADD PARENT</h4>
			</div>
			<form class="bs-example form-horizontal ng-pristine ng-valid" method="POST" action="<?php echo base_url(); ?>students/add_parent/<?php echo $student_details['user_id']; ?>">
			<div class="modal-body">
		      	<div class="panel panel-default">
		      			<div class="panel-heading">Personal Details</div>
				        <div class="panel-body">
							<?php  echo validation_errors(); ?>
				        		<div class="row">
				        			<div class=" col-sm-4">
										<?php //echo form_error('ptitle'); ?>
										<label class="control-label">Title: </label>
										<input class="form-control" value="<?php echo set_value('ptitle',$parent_details['title']); ?>" name="ptitle" id="title"  required="" type="text">
									</div>
									<div class=" col-sm-4">
										<?php //echo form_error('pinitial'); ?>
										<label class="control-label">Initial: </label>
										<input class="form-control" value="<?php echo set_value('pinitial',$parent_details['initial']); ?>" name="pinitial" id="initial"  required="" type="text">
									</div>
									<div class=" col-sm-4">
										<?php //echo form_error('psurname'); ?>
										<label class="control-label">Surname: </label>
										<input class="form-control" value="<?php echo set_value('psurname',$parent_details['surname']); ?>" name="psurname" id="surname"  required="" type="text">
									</div>
									<div class=" col-sm-4">
										<?php //echo form_error('pfirstname'); ?>
										<label class="control-label">First Name: </label>
										<input class="form-control" value="<?php echo set_value('pfirstname',$parent_details['firstname']); ?>" name="pfirstname" id="firstname"  required="" type="text">
									</div>
									<div class=" col-sm-4">
										<?php //echo form_error('pothername'); ?>
										<label class="control-label">Other Name: </label>
										<input class="form-control" value="<?php echo set_value('pothername',$parent_details['othername']); ?>" name="pothername" id="othername"  required="" type="text">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('pphonenumber'); ?>
										<label class="control-label">Phone Number: </label>
										<input class="form-control" value="<?php echo set_value('pphonenumber',$parent_details['phonenumber']); ?>" name="pphonenumber" id="phonenumber" required="" type="number">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('pemailaddress'); ?>
										<label class="control-label">Email Address: </label>
										<input class="form-control" value="<?php echo set_value('pemailaddress',$parent_details['emailaddress']); ?>" name="pemailaddress" id="emailAddress"  required="" type="email">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('phome_address'); ?>
										<label class="control-label">Home Address: </label> 
										<input placeholder="Home Address" class="form-control" value="<?php echo set_value('phome_address',$parent_details['phome_address']); ?>" name="phome_address" required="" type="text">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('preligion'); ?>
										<label class="control-label">Religion: </label>
										<select class="form-control" name="preligion" id="religion" required="">
											<option value="">---Select Religion---</option>
											<option <?php echo set_select('preligion','Islam'); ?> value="Islam">Islam</option>
											<option <?php echo set_select('preligion','Christianity'); ?> value="Christianity">Christianity</option>
											<option <?php echo set_select('preligion','Traditional'); ?> value="Traditional">Traditional</option>
										</select>
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('pdob'); ?>
										<label class="control-label">D.O.B (DD/MM/YYYY): </label>
										<input class="form-control" value="<?php echo set_value('pdob',$parent_details['dob']); ?>" name="pdob" id="dob" required="" type="text">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('pnationality'); ?>
										<label class="control-label">Nationality: </label>
										<input class="form-control" name="pnationality" value="<?php echo set_value('pnationality',$parent_details['nationality']); ?>" type="text">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('pstate'); ?>
										<label class="control-label">State: </label>
										<select class="form-control state" name="pstate" required="">
											<option <?php  echo set_select('pstate','',TRUE); ?> value=" ">Select</option>
											<option <?php  echo set_select('pstate','Abia'); ?> value="Abia">Abia States</option>
											<option <?php  echo set_select('pstate','Adamawa'); ?> value="Adamawa">Adamawa States</option>
											<option <?php echo set_select('pstate','Akwa Ibom'); ?> value="Akwa Ibom">Akwa Ibom States</option>
											<option <?php  echo set_select('pstate','Anambra'); ?> value="Anambra">Anambra States</option>
											<option <?php  echo set_select('pstate','Bauchi'); ?> value="Bauchi">Bauchi States</option>
											<option <?php  echo set_select('pstate','Bayelsa'); ?> value="Bayelsa">Bayelsa States</option>
											<option <?php  echo set_select('pstate','Benue'); ?> value="Benue">Benue States</option>
											<option <?php  echo set_select('pstate','Borno'); ?> value="Borno">Borno States</option>
											<option <?php  echo set_select('pstate','Cross River'); ?> value="Cross River">Cross River States</option>
											<option <?php  echo set_select('pstate','Delta'); ?> value="Delta">Delta States</option>
											<option <?php  echo set_select('pstate','Ebonyi'); ?> value="Ebonyi">Ebonyi States</option>
											<option <?php  echo set_select('pstate','Edo'); ?> value="Edo">Edo States</option>
											<option <?php  echo set_select('pstate','Ekiti'); ?> value="Ekiti">Ekiti States</option>
											<option <?php  echo set_select('pstate','Enugu'); ?> value="Enugu">Enugu States</option>
											<option <?php  echo set_select('pstate','FCT-Abuja'); ?> value="FCT-Abuja">FCT-Abuja</option>
											<option <?php  echo set_select('pstate','Gombe'); ?> value="Gombe">Gombe States</option>
											<option <?php  echo set_select('pstate','Imo'); ?> value="Imo">Imo States</option>
											<option <?php  echo set_select('pstate','Jigawa'); ?> value="Jigawa">Jigawa States</option>
											<option <?php  echo set_select('pstate','Kaduna'); ?> value="Kaduna">Kaduna States</option>
											<option <?php echo set_select('pstate','Kano'); ?> value="Kano">Kano States</option>
											<option <?php  echo set_select('pstate','Katsina'); ?> value="Katsina">Katsina States</option>
											<option <?php  echo set_select('pstate','Kebbi'); ?> value="Kebbi">Kebbi States</option>
											<option <?php  echo set_select('pstate','Kogi'); ?> value="Kogi">Kogi States</option>
											<option <?php  echo set_select('pstate','Kwara'); ?> value="Kwara">Kwara States</option>
											<option <?php  echo set_select('pstate','Lagos'); ?> value="Lagos">Lagos States</option>
											<option <?php  echo set_select('pstate','Nasarawa'); ?> value="Nasarawa">Nasarawa States</option>
											<option <?php  echo set_select('pstate','Niger'); ?> value="Niger">Niger States</option>
											<option <?php  echo set_select('pstate','Ogun'); ?> value="Ogun">Ogun States</option>
											<option <?php  echo set_select('pstate','Ondo'); ?> value="Ondo">Ondo States</option>
											<option <?php  echo set_select('pstate','Osun'); ?> value="Osun">Osun States</option>
											<option <?php  echo set_select('pstate','Oyo'); ?> value="Oyo">Oyo States</option>
											<option <?php  echo set_select('pstate','Plateau'); ?> value="Plateau">Plateau States</option>
											<option <?php  echo set_select('pstate','Rivers'); ?> value="Rivers">Rivers States</option>
											<option <?php  echo set_select('pstate','Sokoto'); ?> value="Sokoto">Sokoto States</option>
											<option <?php  echo set_select('pstate','Taraba'); ?> value="Taraba">Taraba States</option>
											<option <?php  echo set_select('pstate','Yobe'); ?> value="Yobe">Yobe States</option>
											<option <?php echo set_select('pstate','Zamfara'); ?> value="Zamfara">Zamfara States</option>
											<option <?php echo set_select('pstate','Non-Nigerian'); ?> value="Non-Nigerian">Non-Nigerian</option>
										</select>
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('plga'); ?>
										<label class="control-label">Local Government Area: </label>
										<select id="response" class="form-control lga" name="plga" required="">
											<option <?php echo set_select('plga','',TRUE); ?>  value="">Select</option>
											<option <?php echo set_select('plga','Ogun Waterside'); ?>  value="Ogun Waterside">Ogun Waterside</option>
										</select>
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('phometown'); ?>
										<label class="control-label">Hometown: </label>
										<input class="form-control" name="phometown" value="<?php echo set_value('phometown',$parent_details['hometown']); ?>" type="text">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('prelationship'); ?>
										<label class="control-label">Relationship: </label>
										<input class="form-control" value="<?php echo set_value('prelationship',$parent_details['relationship']); ?>" name="prelationship"  required="" type="text">
<!-- 										<span class="help-block">Father, Mother, Brother</span>
 -->									</div>
									<div class="col-sm-4">
										<?php //echo form_error('poccupation'); ?>
										<label class="control-label">Occupation: </label>
										<input class="form-control" value="<?php echo set_value('poccupation',$parent_details['occupation']); ?>" name="poccupation"  type="text">
									</div>
									<div class="col-sm-4">
										<?php //echo form_error('poccupation_address'); ?>
										<label class="control-label">Occupation Address: </label>
										<input class="form-control" value="<?php echo set_value('poccupation_address',$parent_details['occupation_address']); ?>" name="poccupation_address"  type="text">
									</div>
								</div>

			        	</div>
			    </div>
		    </div>			       		
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			</div>
				</form>
		</div>

	</div>
</div>


