<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
    <!-- content -->
    <div class="app-content">
      <div ui-butterbar></div>
      <a href class="off-screen-toggle hide" data-toggle="class:off-screen" data-target=".app-aside" ></a>
      <div class="app-content-body fade-in-up">
        <!-- COPY the content from "tpl/" -->
		<div class="bg-light lter b-b wrapper-md">

		  <span class="pull-right" >
		  	<button class="btn btn-default btn-addon  "><i class="icon-user-female"></i></i>PARENT INFO</button>
		  </span>

		  <h1 class="m-n font-thin h3">Add Students</h1>

		</div>
		<div class="wrapper-md">

		<div class="col-md-12">
			<?php // echo validation_errors(); ?>
			<div class="alert alert-info fade in widget-inner">
                <button type="button" class="close" data-dismiss="alert">x</button>
              Please Enter correct Information      
            </div>
			<?php
			if(!empty($_SESSION['failed'])){?>
				<div class="alert alert-danger fade in widget-inner">
					<button type="button" class="close" data-dismiss="alert">x</button>
					<?php echo $_SESSION['failed']; ?>
				</div>
			<?php }elseif(!empty($_SESSION['success'])){?>
				<div class="alert alert-success fade in widget-inner">
					<button type="button" class="close" data-dismiss="alert">x</button>
					<?php echo $_SESSION['success'];?>
				</div>
			<?php }
			?>
        </div>
			<form class="bs-example form-horizontal ng-pristine ng-valid" method="POST" action="<?php echo base_url(); ?>students/add_student">
			<div class="col-sm-6">
				<div class="panel panel-default">
					<div class="panel-heading ">PERSONAL DETAILS</div>
					<div class="panel-body">

						<div class="form-group">
							<?php echo form_error('sname'); ?>
							<label class="col-sm-4 control-label">Surname: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('sname'); ?>" name="sname" id="surname"  required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('fname'); ?>
							<label class="col-sm-4 control-label">First Name: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('fname'); ?>" name="fname" id="firstName"  required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('mname'); ?>
							<label class="col-sm-4 control-label">Other Name: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('mname'); ?>" name="mname" id="otherName"  required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('phone'); ?>
							<label class="col-sm-4 control-label">Phone Number: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('phone'); ?>" name="phone" id="phoneNumber" required="" type="number">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('email'); ?>
							<label class="col-sm-4 control-label">Email Address: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('email'); ?>" name="email" id="emailAddress"  required="" type="email">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('gender'); ?>
							<label class="col-sm-4 control-label">Gender: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('gender'); ?>" name="gender"  required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('address'); ?>
							<label class="col-sm-4 control-label">Home Address: </label>
							<div class="col-sm-8">
								<input placeholder="Home Address" class="form-control" value="<?php echo set_value('address'); ?>" name="address" required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('religion'); ?>
							<label class="col-sm-4 control-label">Religion: </label>
							<div class="col-sm-8">
								<select class="form-control" name="religion" id="religion" required="">
									<option <?php echo set_select('religion','',TRUE); ?> value="">---Select Religion---</option>
									<option <?php echo set_select('religion','Islam'); ?> value="Islam">Islam</option>
									<option <?php echo set_select('religion','Christianity'); ?> value="Christianity">Christianity</option>
									<option <?php echo set_select('religion','Traditional'); ?> value="Traditional">Traditional</option>
								</select>
							</div>
						</div>


						<div class="form-group">
							<?php echo form_error('dob'); ?>
							<label class="col-sm-4 control-label">D.O.B (DD/MM/YYYY): </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('dob'); ?>" name="dob" id="dob" required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('nationality'); ?>
							<label class="col-sm-4 control-label">Nationality: </label>
							<div class="col-sm-8">
								<input class="form-control" name="nationality" value="<?php echo set_value('nationality'); ?>" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('state'); ?>
							<label class="col-sm-4 control-label">State:</label>
							<div class="col-sm-8">
								<select class="form-control state" name="state" required="">
									<!-- 								<option <?php echo set_select('state','Ogun'); ?> value="Ogun">Ogun</option> -->
									<option <?php echo set_select('state','',TRUE); ?> value=" ">Select</option>
									<option <?php echo set_select('state','Abia'); ?> value="Abia">Abia States</option>
									<option <?php echo set_select('state','Adamawa'); ?> value="Adamawa">Adamawa States</option>
									<option <?php echo set_select('state','Akwa Ibom'); ?> value="Akwa Ibom">Akwa Ibom States</option>
									<option <?php echo set_select('state','Anambra'); ?> value="Anambra">Anambra States</option>
									<option <?php echo set_select('state','Bauchi'); ?> value="Bauchi">Bauchi States</option>
									<option <?php echo set_select('state','Bayelsa'); ?> value="Bayelsa">Bayelsa States</option>
									<option <?php echo set_select('state','Benue'); ?> value="Benue">Benue States</option>
									<option <?php echo set_select('state','Borno'); ?> value="Borno">Borno States</option>
									<option <?php echo set_select('state','Cross River'); ?> value="Cross River">Cross River States</option>
									<option <?php echo set_select('state','Delta'); ?> value="Delta">Delta States</option>
									<option <?php echo set_select('state','Ebonyi'); ?> value="Ebonyi">Ebonyi States</option>
									<option <?php echo set_select('state','Edo'); ?> value="Edo">Edo States</option>
									<option <?php echo set_select('state','Ekiti'); ?> value="Ekiti">Ekiti States</option>
									<option <?php echo set_select('state','Enugu'); ?> value="Enugu">Enugu States</option>
									<option <?php echo set_select('state','FCT-Abuja'); ?> value="FCT-Abuja">FCT-Abuja</option>
									<option <?php echo set_select('state','Gombe'); ?> value="Gombe">Gombe States</option>
									<option <?php echo set_select('state','Imo'); ?> value="Imo">Imo States</option>
									<option <?php echo set_select('state','Jigawa'); ?> value="Jigawa">Jigawa States</option>
									<option <?php echo set_select('state','Kaduna'); ?> value="Kaduna">Kaduna States</option>
									<option <?php echo set_select('state','Kano'); ?> value="Kano">Kano States</option>
									<option <?php echo set_select('state','Katsina'); ?> value="Katsina">Katsina States</option>
									<option <?php echo set_select('state','Kebbi'); ?> value="Kebbi">Kebbi States</option>
									<option <?php echo set_select('state','Kogi'); ?> value="Kogi">Kogi States</option>
									<option <?php echo set_select('state','Kwara'); ?> value="Kwara">Kwara States</option>
									<option <?php echo set_select('state','Lagos'); ?> value="Lagos">Lagos States</option>
									<option <?php echo set_select('state','Nasarawa'); ?> value="Nasarawa">Nasarawa States</option>
									<option <?php echo set_select('state','Niger'); ?> value="Niger">Niger States</option>
									<option <?php echo set_select('state','Ogun'); ?> value="Ogun">Ogun States</option>
									<option <?php echo set_select('state','Ondo'); ?> value="Ondo">Ondo States</option>
									<option <?php echo set_select('state','Osun'); ?> value="Osun">Osun States</option>
									<option <?php echo set_select('state','Oyo'); ?> value="Oyo">Oyo States</option>
									<option <?php echo set_select('state','Plateau'); ?> value="Plateau">Plateau States</option>
									<option <?php echo set_select('state','Rivers'); ?> value="Rivers">Rivers States</option>
									<option <?php echo set_select('state','Sokoto'); ?> value="Sokoto">Sokoto States</option>
									<option <?php echo set_select('state','Taraba'); ?> value="Taraba">Taraba States</option>
									<option <?php echo set_select('state','Yobe'); ?> value="Yobe">Yobe States</option>
									<option <?php echo set_select('state','Zamfara'); ?> value="Zamfara">Zamfara States</option>
									<option <?php echo set_select('state','Non-Nigerian'); ?> value="Non-Nigerian">Non-Nigerian</option>
								</select>
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('lg'); ?>
							<label class="col-sm-4 control-label">Local Government Area:</label>
							<div class="col-sm-8">
								<select id="response" class="form-control lga" name="lg" required="">
									<option <?php echo set_select('lg','Ogun Waterside'); ?>  value="Ogun Waterside">Ogun Waterside</option>
									<option <?php echo set_select('lg','',TRUE); ?>  value="">Select</option>
								</select>
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('hometown'); ?>
							<label class="col-sm-4 control-label">Hometown: </label>
							<div class="col-sm-8">
								<input class="form-control" name="hometown" value="<?php echo set_value('hometown'); ?>" type="text">
							</div>
						</div>


					</div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-default">
					<div class="panel-heading ">ADMISSION INFO</div>
					<div class="panel-body">
						<!--  <form class="bs-example form-horizontal ng-pristine ng-valid">		 -->
						<div class="form-group">
							<?php echo form_error('admission_no'); ?>
							<label class="col-sm-4 control-label">Admission No: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('admission_no'); ?>" name="admission_no"   required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('admission_class'); ?>
							<label class="col-sm-4 control-label">Class: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('admission_class'); ?>" name="admission_class" id="class"  required="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('admission_date'); ?>
							<label class="col-sm-4 control-label">Admission Date: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('admission_date'); ?>" name="admission_date"  required="">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('sport_house'); ?>
							<label class="col-sm-4 control-label">Sport House: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('sport_house'); ?>" name="sport_house" id="" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('hostel_status'); ?>
							<label class="col-sm-4 control-label">Day/Boarding:: </label>
							<div class="col-sm-8">
								<input class="form-control" name="hostel_status" value="<?php echo set_value('hostel_status'); ?>" type="text">
							</div>
						</div>


					</div>
				</div>
			</div>

			<div class="col-sm-6">
				<div class="panel panel-default">
					<div class="panel-heading ">MEDICAL INFO</div>
					<div class="panel-body">
						<!-- <form class="bs-example form-horizontal ng-pristine ng-valid"> -->
						<div class="form-group">
							<?php echo form_error('height'); ?>
							<label class="col-sm-4 control-label">Height: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('height'); ?>" name="height">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('weight'); ?>
							<label class="col-sm-4 control-label">Weight: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('weight'); ?>" name="weight" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('disability'); ?>
							<label class="col-sm-4 control-label">Disablity: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('disability'); ?>" name="disability" type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('genotype'); ?>
							<label class="col-sm-4 control-label">Genotype: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('genotype'); ?>" name="genotype"  type="text">
							</div>
						</div>

						<div class="form-group">
							<?php echo form_error('bloodgroup'); ?>
							<label class="col-sm-4 control-label">Bloodgroup: </label>
							<div class="col-sm-8">
								<input class="form-control" value="<?php echo set_value('bloodgroup'); ?>" name="bloodgroup" type="text">
							</div>
						</div>



					</div>
				</div>
			</div>

	    	<div class="clearfix"></div>
	    <div class="col-md-12">
	    	<div class="panel panel-default">
	    		<div class="panel-body">
	    		<div class="form-actions text-right">
	    			<button class="btn btn-info btn-addon"><i class="fa fa-save"></i>Save</button>
	            </div>
	            </div>
	        </div>
        </div>
			</form>
		<div class="clearfix"></div>

    </div>
    <!-- /content -->


