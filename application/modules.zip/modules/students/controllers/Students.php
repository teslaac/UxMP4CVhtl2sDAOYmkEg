<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require (APPPATH."modules/core/controllers/secure_area.php");



class Students extends Secure_area {	

	function __construct(){

		$this->data['module'] = 'students'; //module name 
		parent::__construct($this->data['module']);
		$this->load->model('student');
	}

	public function index()
	{   

		

		if($this->userdata['user_type'] == 'admin'){
			//I need to have the query for the users from the db
			$this->data['students'] = $this->student->get_all_students();
			//	print_r($data);
			// die();
			$this->data['page'] = 'students';
			$this->load->view('core/template/header', $this->data);
			$this->load->view('students/students');

		}elseif ($this->userdata['user_type'] == 'staff') {
			
			$this->data['page'] = 'students Assigned';
			$this->load->view('core/template/header', $this->data);
			$this->load->view('students/students_assigned');
		}
			
		$this->load->view('core/template/footer');
	}


	public function api($userid = ''){
		//I need to have the query for the users from the db
			$this->data['students'] = $this->student->get_all_students();
			print_r(json_encode($this->data['students']));
			// die();
	}


	public function view()
	{   
		$this->data['page'] = 'students';
		$this->data['students'] = $this->student->get_all_students();
		$this->load->view('core/template/header', $this->data);
		$this->load->view('students/students');
		$this->load->view('core/template/footer');
	}

	public function add()
	{   
		$this->data['page'] = 'students';
		$this->load->view('core/template/header', $this->data);
		$this->load->view('students/add_student');
		$this->load->view('core/template/footer');
	}	

	public function quick_reg()
	{   
		$this->data['page'] = 'students';
		$this->load->view('core/template/header', $this->data);
		$this->load->view('students/students_quick_reg');
		$this->load->view('core/template/footer');
	}

	public function edit($id)
	{
		//if(empty($id)){redirect("students");}
		$this->data['student_details'] = $this->student->get_student($id);
		$this->data['page'] = 'students';
		$this->data['parents_details'] = $this->student->get_parent($id);
		$this->data['parent_details'] = null;
		$this->load->view('core/template/header', $this->data);
		$this->load->view('students/edit_student');
		$this->load->view('core/template/footer');
	}

	public function students($action = 'view')
	{
		$this->data['page'] = 'students';
		$this->data['students'] = $this->student->get_all_students();
		if ($action === 'add'){
			$this->load->view('core/template/header', $this->data);
			$this->load->view('students/add_student');
			$this->load->view('core/template/footer');

		}elseif ($action === 'quick_reg') {
			$this->load->view('core/template/header', $this->data);
			$this->load->view('students/students_quick_reg');
			$this->load->view('core/template/footer');
		}else{
			$this->load->view('core/template/header', $this->data);
			$this->load->view('students/students');
			$this->load->view('core/template/footer');
		}
		
	}

    /**
     * @author Salako Teslim Akolade<tescointsite@gmail.com>
     * This function will add both student and staff users
     *
     * This Function Now Only adds Student and edits student
     */
    public function add_student($mode = "add",$id = NULL)
    {
        //Validating General Info
        $this->form_validation->set_rules('fname', 'First Name', 'trim|required|min_length[5]|max_length[22]');
        $this->form_validation->set_rules('sname', 'Surname', 'trim|required|min_length[5]|max_length[22]');
        $this->form_validation->set_rules('mname', 'Middle Name', 'trim|required|min_length[5]|max_length[22]');
        $this->form_validation->set_rules('phone', 'Phone Number', 'trim|required|min_length[10]|max_length[11]|numeric');
        $this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required|min_length[1]|max_length[6]');
        $this->form_validation->set_rules('address', 'Home Address', 'trim|required|min_length[5]');
        $this->form_validation->set_rules('religion', 'Religion', 'trim|required|max_length[15]|alpha');
        $this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
        $this->form_validation->set_rules('nationality', 'Nationality', 'trim|required|min_length[3]|max_length[22]');
        $this->form_validation->set_rules('state', 'State', 'trim|required');
        $this->form_validation->set_rules('lg', 'L.G.A', 'trim|required');
        $this->form_validation->set_rules('hometown', 'Home Town', 'trim|required|min_length[5]|max_length[22]');

        //Validating Medical Information Provided No room for exploits

        $this->form_validation->set_rules('weight', 'Weight', 'trim|required');
        $this->form_validation->set_rules('height', 'Height', 'trim|required');
        $this->form_validation->set_rules('disability', 'Disability', 'trim|required');
        $this->form_validation->set_rules('genotype', 'Genotype', 'trim|required');
        $this->form_validation->set_rules('bloodgroup', 'Bloodgroup', 'trim|required');
        /**
         * The Reason For adding If statement here is that I dont wanna repeat myself by creating another function
         * to add staff which will probably include all the fields listed above so instead am using the if statement
         * which means from the form the values will be sent is where the logic to use will be defined
         *
         * In the New Version Of Acadah Students and Staff are now separated as a result I am removing the if statement
         */

//            $_SESSION['schoolid'] = $_SESSION['sch_id'];
//            $_SESSION['sch_short_name'] = "CGPA";
            $table = "acadah_student";
//            $usertype = "student";
            //Validating Admission Info Provided no room for exploits

            $this->form_validation->set_rules('admission_no', 'Admission No', 'trim|required');
            $this->form_validation->set_rules('admission_class', 'Admission Class', 'trim|required');
            $this->form_validation->set_rules('admission_date', 'Admission Date', 'trim|required');
            $this->form_validation->set_rules('sport_house', 'Sport House', 'trim|required');
            $this->form_validation->set_rules('hostel_status', 'Day/Boarding', 'trim|required');
            //Validating Parent Info provided

//            $this->form_validation->set_rules('p_full_name', 'Parent Full Name', 'trim|required');
//            $this->form_validation->set_rules('p_full_address', 'Parent Full Address', 'trim|required');
//            $this->form_validation->set_rules('p_relationship', 'Parent Relationship', 'trim|required');
//            $this->form_validation->set_rules('p_email', 'Parents Email', 'trim|required|valid_email');
//            $this->form_validation->set_rules('p_occupation', 'Parents Occupation', 'trim|required');
//            $this->form_validation->set_rules('p_occupation_address', 'Parents Occupation Address', 'trim|required');
//            $this->form_validation->set_rules('p_phone', 'Parents Phone', 'trim|required|min_length[10]|max_length[11]|numeric');


            $odata = array(
                'admission_no' => $this->input->post('admission_no'),
                'admission_class' => $this->input->post('admission_class'),
                'admission_date' => $this->input->post('admission_date'),
                'sport_house' => $this->input->post('sport_house'),
                'religion' => $this->input->post('religion'),
                'weight' => $this->input->post('weight'),
                'height' => $this->input->post('height'),
                'disability' => $this->input->post('disability'),
                'genotype' => $this->input->post('genotype'),
                'bloodgroup' => $this->input->post('bloodgroup'),
                'hostel_status' => $this->input->post('hostel_status')

            );
            //This will be the table name to be passed in the function inside model
        //Now Checking If any of the conditions above was not met
        if($this->form_validation->run() === FALSE){
			if($mode === 'edit'){
				$this->edit($id);
			}else{
				$this->students('add');
			}

        }else {
			//Next Here would be to insert the data into the db so am gonna do that now but first load the model

			//Next am gonna put the data to be inserted into the db in an array
			$udata = array(
				'fname' => $this->input->post('fname'),
				'lname' => $this->input->post('sname'),
				'mname' => $this->input->post('mname'),
				'phone' => $this->input->post('phone'),
				'email' => $this->input->post('email'),
				'gender' => $this->input->post('gender'),
				'address' => $this->input->post('address'),
				'dob' => $this->input->post('dob'),
				'nationality' => $this->input->post('nationality'),
				'state_of_origin' => $this->input->post('state'),
				'lg' => $this->input->post('lg'),
				'hometown' => $this->input->post('hometown'),
				'user_type' => "student",
				'sch_id' => $_SESSION['sch_id'],
				'pass' => md5($this->input->post('surname'))
			);
			//Next Is to call the function inside the model that will do the insertion
			//Am Storing that in a variable just to check for some stuffs :)
			if ($mode === 'edit') {
				$edit = $this->student->edit_student($table, $udata, $odata,$id);
				if ($edit !== TRUE) {
					$this->session->set_flashdata('failed', $edit);
				} elseif ($edit === TRUE) {
					//What Should Happen If the Condition was met
					$this->session->set_flashdata('success', 'User Editted Successfully');
					redirect("students/edit/$id");
				}
				$this->edit($id);
			} else {
				$add = $this->student->add_user($table, $udata, $odata);
				if ($add !== TRUE) {
					$this->session->set_flashdata('failed', $add);
				} elseif ($add === TRUE) {
					//What Should Happen If the Condition was met
					$this->session->set_flashdata('success', 'User Added Successfully');
					redirect('students/add');
				}
				$this->students('add');

			}
		}

    }

	//Now Function To Add Parent For Students
	public function add_parent($id){
		//Validating General Info
		$this->form_validation->set_rules('pfirstname', 'First Name', 'trim|required|min_length[5]|max_length[22]');
		$this->form_validation->set_rules('psurname', 'Surname', 'trim|required|min_length[5]|max_length[22]');
		$this->form_validation->set_rules('pothername', 'Other Name', 'trim|required|min_length[5]|max_length[22]');
		$this->form_validation->set_rules('pphonenumber', 'Phone Number', 'trim|required|min_length[10]|max_length[11]|numeric');
		$this->form_validation->set_rules('pemailaddress', 'Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('pinitial', 'Initial', 'trim|required|min_length[2]|max_length[10]');
		$this->form_validation->set_rules('phome_address', 'Home Address', 'trim|required|min_length[5]');
		$this->form_validation->set_rules('preligion', 'Religion', 'trim|required|max_length[15]|alpha');
		$this->form_validation->set_rules('pdob', 'Date Of Birth', 'trim|required');
		$this->form_validation->set_rules('pnationality', 'Nationality', 'trim|required|min_length[3]|max_length[22]');
		$this->form_validation->set_rules('pstate', 'State', 'trim|required');
		$this->form_validation->set_rules('plga', 'L.G.A', 'trim|required');
		$this->form_validation->set_rules('phometown', 'Home Town', 'trim|required|min_length[5]|max_length[22]');
		$this->form_validation->set_rules('prelationship', 'Parent Relationship', 'trim|required');
		$this->form_validation->set_rules('poccupation', 'Parents Occupation', 'trim|required');
		$this->form_validation->set_rules('poccupation_address', 'Parents Occupation Address', 'trim|required');
		if($this->form_validation->run() === FALSE){
			$this->edit("$id");
		}else{
			$udata = array(
				'fname' => $this->input->post('pfirstname'),
				'lname' => $this->input->post('psurname'),
				'mname' => $this->input->post('pothername'),
				'phone' => $this->input->post('pphonenumber'),
				'email' => $this->input->post('pemailaddress'),
				'address' => $this->input->post('phome_address'),
				'dob' => $this->input->post('pdob'),
				'nationality' => $this->input->post('pnationality'),
				'state_of_origin' => $this->input->post('pstate'),
				'lg' => $this->input->post('plga'),
				'hometown' => $this->input->post('phometown'),
				'user_type' => "parent",
				'sch_id' => $_SESSION['sch_id'],
				'pass' => md5($this->input->post('psurname'))

			);
			$odata = array(
				'initial' => $this->input->post('pinitial'),
				'occupation' => $this->input->post('poccupation'),
				'occupation_address' => $this->input->post('poccupation_address'),
				'relationship' => $this->input->post('prelationship'),
				'title' => $this->input->post('ptitle')
			);
			//Now the function to add the parent in model
			$add = $this->student->add_parent($udata,$odata,$id);
			if ($add !== TRUE) {
				$this->session->set_flashdata('failed', $add);
			} elseif ($add === TRUE) {
				//What Should Happen If the Condition was met
				$this->session->set_flashdata('success', 'Parent Added Successfully');
				redirect("students/edit/$id");
			}
			$this->edit($id);
		}
	}



}
