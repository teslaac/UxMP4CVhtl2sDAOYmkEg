<?php
class Feesm extends CI_Model
{
	/*
	Determines if a given sch_id is an school
	*/
	function exists($sch_id)
	{
			 $sql ="SELECT DISTINCT SUM(pamount) AS total_amount, st.stucat, st.student_id, st.lastname, st.surname, st.firstname, st.gender,  st.ts_id,
			 scr.class_details_id, scr.term_id, scr.session_id, cd.class_level, scr.student_id, cd.class_details, cd.class_details_id";
			 
			 $sql .= " FROM  acadah_student st
			 JOIN acadah_student_class_reg scr ON ( scr.student_id = st.student_id AND scr.ts_id = '$ts_id' )
			 JOIN acadah_class_details cd  ON (cd.class_details_id  = scr.class_details_id)
			 JOIN acadah_term_session ts   ON (term_session_id = '$ts_id')
			 LEFT JOIN acadah_payment_settings ps ON ( pclass = scr.class_details_id AND ps.ts_id = '$ts_id' AND newstu = 0) 
			 						  OR ( pclass = scr.class_details_id AND ps.ts_id = '$ts_id' AND newstu = st.stucat )
			 GROUP BY st.student_id		  
			 ORDER BY cd.class_level, st.surname";

		 $result_1 = mysqli_query($dbc, $sql);  
		
	}


	function total_extra_outstanding($student_id, $ts_id,$dbc){
				/// Calculate SUM Current extra Outstanding
						$sql3 ="select SUM(amount_paid) AS total_amount from payment_bill  WHERE stu_id = '$student_id'AND
							   ts_id = '$ts_id' and payment_type = 0";
					
						$result3 = mysqli_query($dbc, $sql3);					                       
						$r_result = mysqli_fetch_array($result3);
						$total_extra_outstanding = $r_result['total_amount']; 
						return $total_extra_outstanding;
						 }

	/*
	Returns all the students valid for the session, with payment details
	*/
	 function get_all_students($ts_id){

		$sch_id = $_SESSION['sch_id'];
		// $query = $this->db->get_where('acadah_users',array('sch_id'=>$sch_id,'user_type'=>'student'));
		// return $query->result_array();
		//select SUM(amount_paid) AS total_amount from payment_bill  WHERE stu_id = '$student_id'AND
		///					   ts_id = '$ts_id' and payment_type = 0
		
		$this->db->select('*');
		$this->db->select_sum('pamount');
		$this->db->select_sum('payment_balance');
		$this->db->select_sum('trans_amount_paid');

		$this->db->from('student st');
		$this->db->join('users', 'users.user_id = st.student_id and users.sch_id = "'.$sch_id.'"');	
		$this->db->join('student_reg sr', 'users.user_id = sr.student_id  and sr.ts_id ='.$ts_id);		
		$this->db->join('class_details cd', 'cd.class_details_id = sr.class_details_id');		
		$this->db->join('transactions tr', 'tr.student_id = st.student_id AND tr.suspended = 0 AND tr.ts_id = '.$ts_id, 'left');		
		$this->db->join('payment_settings ps', 'ps.pclass = sr.class_details_id  AND ps.stu_cat = st.stu_cat');		
		$this->db->or_where('ps.ts_id = 0');
		$this->db->or_where('ps.ts_id = '.$ts_id);

		//$this->db->where_in($user_type.'.'.$user_type.'_id',$user_ids);
		$this->db->order_by("cd.class_level", "asc");
		$this->db->group_by("st.student_id");

		 $result =  $this->db->get()->result_array();
			 //echo ($this->db->last_query());

		return($result);
	}
	

	// function prev_balance($student_id, $ts_id,$dbc){
	// 			/// Calculate SUM Previous Outstanding
	// 						$sql9 ="select balance from payment_rec WHERE stu_id = '$student_id'AND paym_name_id = 1 and ts_id = (('$ts_id') - 1) ";					
	// 						$result9 = mysqli_query($dbc, $sql9);					                       
	// 						$r_result = mysqli_fetch_array($result9);
	// 						$prev_balance = $r_result['balance'];
	// 					    return $prev_balance;
	// 					 }

	function payment_balance($student_id){
				/// Calculate SUM Previous Outstanding
				$this->db->select_sum('payment_balance');
				$result = $this->db->get_where('student_reg', array('student_id'=>$student_id));
				return $result->result_array(0);
			}

	function prev_balance($student_id, $ts_id=''){
				if($ts_id == ''){$ts_id = $_SESSION['active_term_session_data']['ts_id'];} //check if ts_id is sent

				/// Calculate SUM Previous Outstanding
				$this->db->select_sum('payment_balance');
			    $result = $this->db->get_where('student_reg', array('student_id'=>$student_id, 'ts_id <' => $ts_id ));
				return $result->row()->payment_balance;
			
			}




}
?>
