<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="" />
  <title>Acadah  | Smart School </title>
  <meta name="description" content="app, web app, responsive, responsive layout, admin, admin panel, admin dashboard, flat, flat ui, ui kit, AngularJS, ui route, charts, widgets, components" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url();?>css/printpages.css" type="text/css" />
</head>

<body>

<div class="container">
  <div class="content">
  
  
  <div id="headwrap">
  <div class="logo"><img src="<?php echo base_url();?>img/ccclear.png" alt="." height="115" width="115"></div>
  <div class="headings">
        <h2>COOLCHI COLLEGE.</h2>
        <h5>CONSISTENCY AND TRUST IN GOD </h5>
        <h4><span class="title">  </span></h4>
        <p> <span class="title" style="font-size:11px;"> Email: coolchicollege15@gmail.com Web: www.coolchicollege.com Phone: 07038917937</span></p>
      </div>
      
		


    </div>
     <div class="clear"></div>
	   <div class="title2"> CLASS LIST  </div>

  <div class="wrap2">  
    <!-- Main content wrapper -->
  <div class="wrap2">
	<table class="altrowstable" id="alternatecolor">
	<tbody><tr>
		<td>Session: <b>2014/2015</b></td> 
		<td> Term: <b>1st Term</b></td>
		<td>Class: <b>JSS 1</b></td>
		<td>No. in Class:<b> 22</b></td>
	</tr> 
	</tbody></table>
  </div>	

 <div class="wrap2">	
	<table class="altrowstable">
		<thead>
      <tr style="font-size:12;">
        <th style=" width: 45px">No.</th>
        <th style=" width: 220px">Full Name</th>
        <th style=" width: 55px">Gender </th>
        <th></th>
      </tr>
    </thead>		
		<tbody>
    <tr>
      <td>1</td>
      <td><span style="padding-left: 10px;">Okeke Herieta  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>2</td>
       <td><span style="padding-left: 10px;">Osikhe Lamai  </span></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>4</td>
       <td><span style="padding-left: 10px;">Chukwuka George   </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>5</td>
       <td><span style="padding-left: 10px;">Uduehi-Agabri Thelma  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>6</td>
       <td><span style="padding-left: 10px;">Duru Zite  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>7</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr>  
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td>M</td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    <tr>
      <td>3</td>
       <td><span style="padding-left: 10px;">Ifeanyi Solomon  </span></td>
      <td></td>
      <td></td>
    </tr> 
    </tbody>

 </table>

	</div>	
		</div>					
			</div>
 <!-- end .container --></div> 
 
 <div class="clear"> </div>
  



</body></html>