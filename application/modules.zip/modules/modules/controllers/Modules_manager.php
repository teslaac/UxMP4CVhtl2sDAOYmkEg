<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modules_manager extends MX_Controller {

	public function index()
	{
		$this->load->view('core/template/header2');
		$this->load->view('modules_manager/modules');
		$this->load->view('core/template/footer');
	}


}
