<?php
class Module extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
        $this->sch_id = $this->session->userdata['sch_id'];
    }
	
	function get_module_name($module_id)
	{
		$query = $this->db->get_where('modules', array('module_id' => $module_id), 1);
		
		if ($query->num_rows() ==1)
		{
			$row = $query->row();
			return lang($row->name_lang_key);
		}
		
		return lang('error_unknown');
	}
	
	function get_module_desc($module_id)
	{
		$query = $this->db->get_where('modules', array('module_id' => $module_id), 1);
		if ($query->num_rows() ==1)
		{
			$row = $query->row();
			return lang($row->desc_lang_key);
		}
	
		return lang('error_unknown');	
	}
	
	function get_all_modules()
	{
		$this->db->from('modules');
		$this->db->order_by("sort", "asc");
		return $this->db->get();		
	}
	
	function get_allowed_modules($access_user_id, $access_user_type)
	{	
		$this->db->from('modules_actions ma');
		$this->db->join('users_permissions_actions upa' ,'upa.action_id = ma.action_id ');
		$this->db->where("upa.access_user_id", $access_user_id);
		$this->db->where("upa.access_user_type", $access_user_type);
		$this->db->where("upa.dashboard", 1);
		$this->db->order_by("sort", "asc");
		$get = $this->db->get()->result_array();
		return $get;	
echo '<pre>';
		 print_r($this->db->last_query());
echo '</pre>';
	}

	function get_allowed_modules_submenu($module_id, $user, $usertype)
	{	

		$this->db->from('modules_actions ma');
		$this->db->join("users_permissions_actions upa", "upa.action_id = ma.action_id ")
		->group_start()
			->where("upa.access_user_id",$user)
			->or_where("upa.access_user_id",$usertype)
		->group_end();
		$this->db->where("ma.module_id",$module_id);
		$this->db->where("ma.sch_id", $this->sch_id);
		$this->db->order_by("sort", "asc");
		$get = $this->db->get()->result_array();
		return $get;	
echo '<pre>';
		 print_r($this->db->last_query());
echo '</pre>'; exit();
	}
}
?>
