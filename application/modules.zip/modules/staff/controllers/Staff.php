<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require (APPPATH."modules/core/controllers/secure_area.php");



class Staff extends Secure_area {	

	function __construct(){

		$this->data['module'] = 'staff'; //module name
		$this->data['states'] = $this->corem->get_states();
		$this->data['classes'] = $this->corem->get_no_class(FALSE);
		$this->data['sport_house'] = $this->corem->get_sport_house();
		parent::__construct($this->data['module']);
		$this->load->model('staffm');
	}

	public function index()
	{
		if($this->userdata['user_type'] == 'admin'){
			$this->data['no_male'] = $this->corem->get_no_gender('male','staff');
			$this->data['no_female'] = $this->corem->get_no_gender('female','staff');
			$this->data['staff'] = $this->user_model->get_all_users('staff','acadah_staff','staff_id');
			$this->data['page'] = 'staff';
			$this->load->view('core/template/header', $this->data);
			$this->load->view('staff/staff');

		}elseif ($this->userdata['user_type'] == 'staff') {
			$this->data['no_male'] = $this->corem->get_no_gender('male','student');
			$this->data['no_female'] = $this->corem->get_no_gender('female','student');
			$this->data['page'] = 'staff Assigned';
			$this->load->view('core/template/header', $this->data);
			$this->load->view('staff/staff_assigned');
		}
			
		$this->load->view('core/template/footer');
	}

	public function view()
	{   
		$this->data['page'] = 'staff';
		$this->data['staff'] = $this->user_model->get_all_users('staff','acadah_staff','staff_id');
		$this->load->view('core/template/header', $this->data);
		$this->load->view('staff/staff');
		$this->load->view('core/template/footer');
	}

	public function add()
	{   
		$this->data['page'] = 'Add Staff';
		$this->load->view('core/template/header', $this->data);
		$this->load->view('staff/add_staff');
		$this->load->view('core/template/footer');
	}

	public function edit($id)
	{
		if(empty($id)){redirect("students");}
		$this->data['staff_details'] = $this->user_model->get_user($id,'acadah_staff','staff_id');
		$this->data['subjects'] = $this->corem->get_no_subjects(FALSE);
		$this->data['class'] = $this->corem->get_no_class(FALSE);
		$this->data['sessions'] = $this->corem->get_session(FALSE);
		$this->data['subjects_details'] = $this->corem->subjects_details($id,'','staff');
		$this->data['page'] = 'Edit Staff';
		$this->load->view('core/template/header', $this->data);
		$this->load->view('staff/edit_staff');
		$this->load->view('core/template/footer');
	}	

	public function quick_reg()
	{   
		$this->data['page'] = 'staff';
		$this->load->view('core/template/header', $this->data);
		$this->load->view('staff/staff_quick_reg');
		$this->load->view('core/template/footer');
	}

	public function staff($action = 'view')
	{
		$this->data['page'] = 'staff';
		$this->data['staff'] = $this->user_model->get_all_users('staff','acadah_staff','staff_id');
		if ($action === 'add'){
			$this->load->view('core/template/header', $this->data);
			$this->load->view('staff/add_staff');
			$this->load->view('core/template/footer');

		}elseif ($action === 'quick_reg') {
			$this->load->view('core/template/header', $this->data);
			$this->load->view('staff/staff_quick_reg');
			$this->load->view('core/template/footer');
		}else{
			$this->load->view('core/template/header', $this->data);
			$this->load->view('staff/staff');
			$this->load->view('core/template/footer');
		}
		
	}

	/**
	 * @author Salako Teslim Akolade<tescointsite@gmail.com>
	 * This function will add both student and staff users
	 *
	 * This Function Now Only adds Staff and edits staff
	 */
	public function add_staff($mode = "add",$id = NULL)
	{
		$table = "acadah_staff";
		$odata = array(
			'file_no' => $this->input->post('file_no'),
			'year_of_employment' => $this->input->post('year_of_employment'),
			'sport_house' => $this->input->post('sport_house'),
			'staff_position' => $this->input->post('staff_position'),
			'staff_type' => $this->input->post('staff_type'),
			'staff_function' => $this->input->post('staff_function'),
			'qualification' => $this->input->post('qualification'),
			'course_studied' => $this->input->post('course_studied'),
			'institution' => $this->input->post('institution'),
			'years_of_exp' => $this->input->post('years_of_exp'),
			'staff_level' => $this->input->post('staff_level'),
			'religion' => $this->input->post('religion'),
			'title' => $this->input->post('title'),
			'initial' => $this->input->post('initial'),
			'marital_status' => $this->input->post('marital_status'),
			'weight' => $this->input->post('weight'),
			'height' => $this->input->post('height'),
			'disability' => $this->input->post('disability'),
			'genotype' => $this->input->post('genotype'),
			'bloodgroup' => $this->input->post('bloodgroup'),
			'marital_status' => $this->input->post('marital_status')

		);
		//This will be the table name to be passed in the function inside model
		//Now Checking If any of the conditions above was not met
		if($this->user_model->general_validation('staff') === FALSE){
			if($mode === 'edit'){
				$this->edit($id);
			}else{
				$this->staff('add');
			}

		}else {
			//Next Here would be to insert the data into the db so am gonna do that now but first load the model

			//Next am gonna put the data to be inserted into the db in an array
			$udata = array(
				'fname' => $this->input->post('fname'),
				'lname' => $this->input->post('sname'),
				'mname' => $this->input->post('mname'),
				'phone' => $this->input->post('phone'),
				'email' => $this->input->post('email'),
				'gender' => $this->input->post('gender'),
				'address' => $this->input->post('address'),
				'dob' => $this->input->post('dob'),
				'nationality' => $this->input->post('nationality'),
				'state_of_origin' => $this->input->post('state'),
				'lg' => $this->input->post('lg'),
				'hometown' => $this->input->post('hometown'),
				'user_type' => "staff",
				'sch_id' => $_SESSION['sch_id'],
				'pass' => md5($this->input->post('surname'))
			);
			//Next Is to call the function inside the model that will do the insertion
			//Am Storing that in a variable just to check for some stuffs :)
			if ($mode === 'edit') {
				$edit = $this->user_model->edit_user($table, $udata, $odata,$id,'staff_id');
				if ($edit !== TRUE) {
					$this->session->set_flashdata('failed', $edit);
				} elseif ($edit === TRUE) {
					//What Should Happen If the Condition was met
					$this->session->set_flashdata('success', 'User Editted Successfully');
					redirect("staff/edit/$id");
				}
				$this->edit($id);
			} else {
				$add = $this->user_model->add_user($udata,$odata,'','staff_id','acadah_staff');
//				$add = $this->staffm->add_user($table, $udata, $odata);
				if ($add !== TRUE) {
					$this->session->set_flashdata('failed', $add);
				} elseif ($add === TRUE) {
					//What Should Happen If the Condition was met
					$this->session->set_flashdata('success', 'User Added Successfully');
					redirect('staff/add');
				}
				$this->staff('add');

			}
		}

	}


	public function add_subject($id){
		$class_id = explode('-',$this->input->post('class_id'));
		$sdata = array(
				'subject_id' => $this->input->post('subject_id'),
				'class_id' => $class_id[0],
				'class_details_id' => $class_id[1],
				'session_id' => $this->input->post('session_id'),
				'sch_id' => $_SESSION['sch_id'],
				'staff_id' => $id
		);
		$add = $this->corem->add_subject($sdata,'staff');
		if ($add !== TRUE) {
			$this->session->set_flashdata('failed', $add);
		} elseif ($add === TRUE) {
			//What Should Happen If the Condition was met
			$this->session->set_flashdata('success', 'Subject Added Successfully');
			redirect("staff/edit/$id");
		}
		$this->edit($id);
	}

}
