<?php

//put common language here 
$lang['common_common']='common';
$lang['common_submit']='Submit';

?>